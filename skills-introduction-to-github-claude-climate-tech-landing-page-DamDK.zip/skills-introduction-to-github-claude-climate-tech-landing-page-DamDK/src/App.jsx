import React from 'react';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Hero from './components/sections/Hero';
import Crisis from './components/sections/Crisis';
import Solution from './components/sections/Solution';
import HowItWorks from './components/sections/HowItWorks';
import Technology from './components/sections/Technology';
import WhyNow from './components/sections/WhyNow';
import FAQ from './components/sections/FAQ';
import Contact from './components/sections/Contact';
import FloatingCTA from './components/ui/FloatingCTA';

function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      {/* Navigation */}
      <Navbar />

      {/* Main Content */}
      <main>
        <Hero />
        <Crisis />
        <Solution />
        <HowItWorks />
        <Technology />
        <WhyNow />
        <FAQ />
        <Contact />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating CTA Button */}
      <FloatingCTA />
    </div>
  );
}

export default App;
