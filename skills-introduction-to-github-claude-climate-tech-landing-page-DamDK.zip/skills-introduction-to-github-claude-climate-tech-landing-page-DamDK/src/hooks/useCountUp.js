import { useState, useEffect, useRef } from 'react';

/**
 * Easing function para animación suave (easeOutQuart)
 */
const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);

/**
 * Hook para animar contadores numéricos con IntersectionObserver
 * @param {number} end - Valor final del contador
 * @param {number} duration - Duración de la animación en ms (default: 2000)
 * @param {boolean} once - Si true, anima solo una vez (default: true)
 * @returns {Object} - { ref, count }
 */
export const useCountUp = (end, duration = 2000, once = true) => {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef(null);
  const observerRef = useRef(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    // Crear IntersectionObserver
    observerRef.current = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && (!once || !hasAnimated)) {
          // Iniciar animación
          const startTime = Date.now();
          const startValue = 0;

          const animate = () => {
            const currentTime = Date.now();
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            // Aplicar easing
            const easedProgress = easeOutQuart(progress);
            const currentValue = Math.floor(startValue + (end - startValue) * easedProgress);

            setCount(currentValue);

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCount(end);
              setHasAnimated(true);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      {
        threshold: 0.3, // Trigger cuando el 30% del elemento es visible
        rootMargin: '0px',
      }
    );

    observerRef.current.observe(element);

    return () => {
      if (observerRef.current && element) {
        observerRef.current.unobserve(element);
      }
    };
  }, [end, duration, once, hasAnimated]);

  return { ref, count };
};

/**
 * Formatea números con separadores de miles
 * @param {number} num - Número a formatear
 * @returns {string} - Número formateado
 */
export const formatNumber = (num) => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
};

export default useCountUp;
