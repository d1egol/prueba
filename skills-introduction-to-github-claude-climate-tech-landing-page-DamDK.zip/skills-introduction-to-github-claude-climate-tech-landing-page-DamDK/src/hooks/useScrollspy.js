import { useState, useEffect } from 'react';

/**
 * Hook para detectar qué sección está actualmente visible en el viewport
 * @param {Array} sectionIds - Array de IDs de las secciones a observar
 * @param {number} offset - Offset desde el top para considerar una sección activa
 * @returns {string} - ID de la sección actualmente activa
 */
export const useScrollspy = (sectionIds, offset = 100) => {
  const [activeSection, setActiveSection] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + offset;

      // Encontrar la sección actual basándonos en la posición del scroll
      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const section = document.getElementById(sectionIds[i]);
        if (section) {
          const sectionTop = section.offsetTop;
          if (scrollPosition >= sectionTop) {
            setActiveSection(sectionIds[i]);
            break;
          }
        }
      }

      // Si estamos en el top, no hay sección activa
      if (window.scrollY < offset) {
        setActiveSection('');
      }
    };

    // Ejecutar al montar para establecer el estado inicial
    handleScroll();

    // Agregar listener con throttling para performance
    let timeoutId;
    const throttledScroll = () => {
      if (timeoutId) {
        return;
      }
      timeoutId = setTimeout(() => {
        handleScroll();
        timeoutId = null;
      }, 100);
    };

    window.addEventListener('scroll', throttledScroll);
    return () => {
      window.removeEventListener('scroll', throttledScroll);
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [sectionIds, offset]);

  return activeSection;
};

export default useScrollspy;
