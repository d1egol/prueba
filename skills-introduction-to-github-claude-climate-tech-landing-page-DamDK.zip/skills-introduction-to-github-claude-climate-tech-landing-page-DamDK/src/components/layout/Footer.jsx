import React from 'react';
import { Flame, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const footerLinks = [
    { id: 'problema', label: 'El Problema' },
    { id: 'solucion', label: 'Solución' },
    { id: 'tecnologia', label: 'Tecnología' },
    { id: 'proceso', label: 'Proceso' },
    { id: 'faq', label: 'FAQ' },
  ];

  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center space-y-8">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Flame className="w-8 h-8 text-accent-500" />
            <span className="text-xl font-bold tracking-tight">FIREWATCH</span>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm">
            {footerLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="text-slate-400 hover:text-primary-400 transition-colors duration-200"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Divider */}
          <div className="w-full border-t border-slate-800" />

          {/* Bottom Row */}
          <div className="flex flex-col md:flex-row items-center justify-between w-full gap-4 text-sm text-slate-500">
            <p className="text-center md:text-left">
              © {currentYear} FireWatch Chile. Todos los derechos reservados.
            </p>

            <div className="flex items-center gap-6">
              {/* LinkedIn */}
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-400 transition-colors duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>

              {/* Dronivo Badge */}
              <div className="flex items-center gap-2 text-slate-400">
                <span className="text-xl">🇩🇪</span>
                <span className="text-xs">
                  Socio tecnológico:{' '}
                  <span className="text-slate-300 font-medium">Dronivo</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
