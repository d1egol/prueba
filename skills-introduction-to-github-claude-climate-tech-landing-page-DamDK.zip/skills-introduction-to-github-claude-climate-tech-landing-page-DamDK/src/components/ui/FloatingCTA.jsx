import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar } from 'lucide-react';

/**
 * Botón CTA flotante que aparece después de hacer scroll
 * @param {number} showAfter - Píxeles de scroll antes de mostrar (default: 500)
 */
const FloatingCTA = ({ showAfter = 500 }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > showAfter) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [showAfter]);

  const scrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={scrollToContact}
          className="fixed bottom-6 right-6 z-50 bg-accent-500 text-white px-6 py-3 rounded-full shadow-2xl shadow-accent-500/30 hover:shadow-accent-500/50 transition-shadow duration-300 flex items-center gap-2 font-medium md:bottom-8 md:right-8"
          aria-label="Agendar reunión"
        >
          <Calendar size={20} />
          <span className="hidden sm:inline">Agendar</span>
        </motion.button>
      )}
    </AnimatePresence>
  );
};

export default FloatingCTA;
