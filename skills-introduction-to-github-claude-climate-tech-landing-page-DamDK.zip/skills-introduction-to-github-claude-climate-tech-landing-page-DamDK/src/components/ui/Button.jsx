import React from 'react';
import { motion } from 'framer-motion';

/**
 * Componente Button reutilizable con variantes de estilo
 * @param {string} variant - 'primary' | 'secondary' | 'outline' | 'ghost'
 * @param {string} size - 'sm' | 'md' | 'lg'
 * @param {ReactNode} children - Contenido del botón
 * @param {ReactNode} icon - Icono opcional (Lucide React)
 * @param {Function} onClick - Handler de click
 * @param {string} className - Clases adicionales
 * @param {boolean} fullWidth - Si el botón ocupa todo el ancho
 */
const Button = ({
  variant = 'primary',
  size = 'md',
  children,
  icon,
  onClick,
  className = '',
  fullWidth = false,
  type = 'button',
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center gap-2 font-medium transition-all duration-300 ease-out rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-950';

  const variants = {
    primary: 'bg-accent-500 text-white hover:bg-accent-600 hover:scale-[1.02] shadow-lg shadow-accent-500/20 hover:shadow-xl hover:shadow-accent-500/30 focus:ring-accent-500',
    secondary: 'bg-primary-500 text-white hover:bg-primary-600 hover:scale-[1.02] shadow-lg shadow-primary-500/20 hover:shadow-xl hover:shadow-primary-500/30 focus:ring-primary-500',
    outline: 'border-2 border-slate-700 text-slate-100 hover:border-primary-500 hover:text-primary-400 hover:bg-primary-500/10 focus:ring-primary-500',
    ghost: 'text-slate-400 hover:text-primary-400 hover:bg-primary-500/10 focus:ring-primary-500',
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  };

  const widthClass = fullWidth ? 'w-full' : '';

  return (
    <motion.button
      whileHover={{ scale: variant !== 'ghost' ? 1.02 : 1 }}
      whileTap={{ scale: 0.98 }}
      type={type}
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${widthClass} ${className}`}
      {...props}
    >
      {children}
      {icon && <span className="inline-flex">{icon}</span>}
    </motion.button>
  );
};

export default Button;
