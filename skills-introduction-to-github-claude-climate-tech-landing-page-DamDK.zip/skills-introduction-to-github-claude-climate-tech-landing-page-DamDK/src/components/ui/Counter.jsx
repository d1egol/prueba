import React from 'react';
import { useCountUp, formatNumber } from '../../hooks/useCountUp';

/**
 * Componente Counter animado con IntersectionObserver
 * @param {number} end - Valor final del contador
 * @param {string} label - Etiqueta descriptiva
 * @param {string} suffix - Sufijo opcional (ej: "+", "k", "%")
 * @param {string} prefix - Prefijo opcional (ej: "$")
 * @param {number} duration - Duración de la animación en ms
 * @param {boolean} format - Si formatea el número con separadores de miles
 */
const Counter = ({
  end,
  label,
  suffix = '',
  prefix = '',
  duration = 2000,
  format = false,
}) => {
  const { ref, count } = useCountUp(end, duration);

  const displayValue = format ? formatNumber(count) : count;

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-mono font-bold text-accent-500 mb-2">
        {prefix}{displayValue}{suffix}
      </div>
      <div className="text-sm md:text-base text-slate-400 leading-tight">
        {label}
      </div>
    </div>
  );
};

export default Counter;
