import React from 'react';
import { motion } from 'framer-motion';

/**
 * Componente Card reutilizable con efectos glassmorphism
 * @param {ReactNode} children - Contenido de la card
 * @param {boolean} hover - Si tiene efecto hover
 * @param {string} className - Clases adicionales
 * @param {boolean} glass - Si usa efecto glassmorphism
 */
const Card = ({
  children,
  hover = false,
  className = '',
  glass = false,
  ...props
}) => {
  const baseStyles = 'rounded-2xl p-6 transition-all duration-300';
  const glassStyles = glass
    ? 'bg-white/5 backdrop-blur-lg border border-white/10'
    : 'bg-slate-800/50 backdrop-blur-sm border border-slate-700';
  const hoverStyles = hover
    ? 'hover:scale-[1.02] hover:shadow-xl hover:shadow-black/20 hover:border-primary-500/50 cursor-pointer'
    : '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5 }}
      className={`${baseStyles} ${glassStyles} ${hoverStyles} ${className}`}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default Card;
