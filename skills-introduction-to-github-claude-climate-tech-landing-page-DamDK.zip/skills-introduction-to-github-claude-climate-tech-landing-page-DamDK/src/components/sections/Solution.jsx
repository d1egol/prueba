import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Bell, Zap, ArrowRight, Star } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const Solution = () => {
  const pillars = [
    {
      number: '1',
      icon: Eye,
      title: 'DETECTAR',
      description: 'Drones 24/7 con cámaras térmicas e IA que identifican focos antes de ser visibles',
      color: 'primary',
    },
    {
      number: '2',
      icon: Bell,
      title: 'ALERTAR',
      description: 'Notificación instantánea a CONAF, SENAPRED y brigadas locales con ubicación exacta',
      color: 'accent',
    },
    {
      number: '3',
      icon: Zap,
      title: 'RESPONDER',
      description: 'Contención inicial con drones de carga mientras llegan los equipos terrestres',
      color: 'forest',
    },
  ];

  const scrollToProcess = () => {
    const processSection = document.getElementById('proceso');
    if (processSection) {
      processSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="solucion" className="py-24 md:py-32 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative overflow-hidden">
      {/* Background Glow Effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-500/10 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">La Solución</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-6 text-balance"
          >
            <span className="text-forest-400">Detectar antes.</span>{' '}
            <span className="text-primary-400">Responder mejor.</span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-slate-300 text-center mb-16 max-w-3xl mx-auto"
          >
            Un sistema integral diseñado específicamente para las condiciones y desafíos de Chile.
          </motion.p>

          {/* Three Pillars with Flow */}
          <div className="relative mb-16">
            {/* Connector Line - Hidden on mobile */}
            <div className="hidden md:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary-500/30 to-transparent" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
              {pillars.map((pillar, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="relative"
                >
                  <Card hover className="h-full text-center">
                    {/* Icon Circle */}
                    <div className={`w-20 h-20 mx-auto mb-6 rounded-full bg-${pillar.color}-500/10 border-2 border-${pillar.color}-500/30 flex items-center justify-center`}>
                      <pillar.icon className={`w-10 h-10 text-${pillar.color}-500`} />
                    </div>

                    {/* Number Badge */}
                    <div className="absolute top-6 right-6 w-8 h-8 rounded-full bg-slate-700 text-slate-300 flex items-center justify-center text-sm font-bold">
                      {pillar.number}
                    </div>

                    {/* Title */}
                    <h3 className={`text-2xl font-bold mb-4 text-${pillar.color}-400`}>
                      {pillar.title}
                    </h3>

                    {/* Description */}
                    <p className="text-slate-300 leading-relaxed">
                      {pillar.description}
                    </p>
                  </Card>

                  {/* Arrow Connector - Hidden on mobile, hidden on last item */}
                  {index < pillars.length - 1 && (
                    <div className="hidden md:block absolute top-1/3 -right-4 z-20">
                      <ArrowRight className="w-8 h-8 text-primary-500/50" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Highlight Box - Diferenciador */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="max-w-4xl mx-auto mb-12"
          >
            <div className="bg-accent-500/10 border border-accent-500/30 rounded-2xl p-6 md:p-8">
              <div className="flex items-start gap-4">
                <Star className="w-6 h-6 text-accent-500 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-xl font-bold text-accent-400 mb-2">
                    Cada proyecto es diseñado A MEDIDA
                  </h4>
                  <p className="text-slate-300 text-lg leading-relaxed">
                    Según tu terreno, cobertura necesaria y sistemas existentes. No vendemos productos genéricos.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-center"
          >
            <Button
              variant="secondary"
              size="lg"
              onClick={scrollToProcess}
              icon={<ArrowRight size={20} />}
            >
              Ver cómo funciona
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Solution;
