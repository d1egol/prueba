import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import Card from '../ui/Card';
import Counter from '../ui/Counter';

const Crisis = () => {
  const stats = [
    {
      value: 428343,
      label: 'hectáreas quemadas en temporada 2022-2023',
      format: true,
      suffix: 'ha',
    },
    {
      value: 64,
      label: 'de incendios causados por negligencia humana',
      format: false,
      suffix: '%',
    },
    {
      value: 2,
      label: 'horas bastaron para quemar 5.500 hectáreas en Valparaíso',
      format: false,
      suffix: 'hrs',
    },
    {
      value: 1000,
      label: 'años: la megasequía más larga registrada (ONU)',
      format: false,
      suffix: '+',
      prefix: '',
    },
  ];

  return (
    <section id="problema" className="py-24 md:py-32 bg-slate-950 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, rgb(248 250 252) 1px, transparent 0)',
          backgroundSize: '48px 48px',
        }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">El Problema</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-16 text-balance"
          >
            Chile enfrenta una crisis{' '}
            <span className="text-alert-500">que escala</span>{' '}
            cada temporada
          </motion.h2>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-16">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: 0.1 * index }}
              >
                <Card hover className="h-full">
                  <Counter
                    end={stat.value}
                    label={stat.label}
                    suffix={stat.suffix}
                    prefix={stat.prefix || ''}
                    format={stat.format}
                  />
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Context Paragraph */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="max-w-4xl mx-auto mb-12"
          >
            <p className="text-lg md:text-xl text-slate-300 text-center leading-relaxed">
              La interfaz urbano-forestal crece. El cambio climático intensifica las condiciones. La detección tardía convierte focos manejables en megaincendios. El tiempo entre la ignición y la respuesta determina si perdemos hectáreas o comunidades enteras.
            </p>
          </motion.div>

          {/* Quote Box */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="max-w-3xl mx-auto"
          >
            <div className="bg-slate-900/50 backdrop-blur-sm border-l-4 border-accent-500 rounded-r-2xl p-6 md:p-8">
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-6 h-6 text-accent-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-lg md:text-xl text-slate-200 italic mb-3 leading-relaxed">
                    "La combinación de vientos y calor hizo que se quemaran más de 5.500 hectáreas en solo 2 horas en Valparaíso"
                  </p>
                  <p className="text-sm text-slate-400 font-medium">
                    — SENAPRED, Febrero 2024
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Crisis;
