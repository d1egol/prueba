import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ArrowRight, Calendar } from 'lucide-react';
import Button from '../ui/Button';
import Counter from '../ui/Counter';

const Hero = () => {
  const scrollToNextSection = () => {
    const nextSection = document.getElementById('problema');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToSolution = () => {
    const solutionSection = document.getElementById('solucion');
    if (solutionSection) {
      solutionSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1448375240586-882707db888b?w=1920&q=80)',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/95 via-slate-900/80 to-slate-950/95" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 py-32 pt-40">
        <div className="max-w-5xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/30 text-primary-400 text-sm font-medium mb-8"
          >
            <span className="text-xl">🇩🇪</span>
            <span>Tecnología alemana · Soluciones a medida para Chile</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-6 text-balance leading-tight"
          >
            Protegemos los bosques de Chile{' '}
            <span className="bg-gradient-to-r from-accent-400 to-forest-400 bg-clip-text text-transparent">
              antes de que sea tarde
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-xl md:text-2xl text-slate-300 mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            Sistema de detección y respuesta temprana a incendios forestales con drones autónomos e inteligencia artificial. Proyectos diseñados a medida para tu operación.
          </motion.p>

          {/* Stats Row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-8 md:gap-12 mb-12 max-w-4xl mx-auto"
          >
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl p-6">
              <Counter end={132} label="vidas perdidas en Valparaíso 2024" format={false} />
            </div>
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl p-6">
              <Counter end={5500} label="hectáreas quemadas en solo 2 horas" format={true} suffix="ha" />
            </div>
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl p-6">
              <div className="text-4xl md:text-5xl font-mono font-bold text-forest-500 mb-2">
                {'<'}5min
              </div>
              <div className="text-sm md:text-base text-slate-400 leading-tight">
                alerta temprana posible
              </div>
            </div>
          </motion.div>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
          >
            <Button
              variant="primary"
              size="lg"
              onClick={scrollToContact}
              icon={<Calendar size={20} />}
            >
              Agendar Reunión Estratégica
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={scrollToSolution}
              icon={<ArrowRight size={20} />}
            >
              Conocer la Solución
            </Button>
          </motion.div>

          {/* Badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="inline-flex items-center gap-2 text-sm text-slate-400"
          >
            <span className="text-xl">🇩🇪</span>
            <span>Socio tecnológico: <span className="text-slate-300 font-medium">Dronivo (Alemania)</span></span>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          onClick={scrollToNextSection}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-slate-400 hover:text-primary-400 transition-colors"
          aria-label="Scroll to next section"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          >
            <ChevronDown size={32} />
          </motion.div>
        </motion.button>
      </div>
    </section>
  );
};

export default Hero;
