import React from 'react';
import { motion } from 'framer-motion';
import { FileCheck, Zap, TrendingUp, Shield } from 'lucide-react';
import Card from '../ui/Card';
import Counter from '../ui/Counter';

const WhyNow = () => {
  const pillars = [
    {
      icon: FileCheck,
      title: 'REGULACIÓN',
      description: 'Chile fue el primer país LATAM en regular drones (DAN 151, 2015). El marco legal existe.',
      stat: '2015',
      statLabel: 'DAN 151',
    },
    {
      icon: Zap,
      title: 'TECNOLOGÍA',
      description: 'La tecnología de drones autónomos alcanzó madurez comercial en 2024.',
      stat: '2024',
      statLabel: 'Madurez comercial',
    },
    {
      icon: TrendingUp,
      title: 'MERCADO',
      description: '$22.47B será el mercado global de wildfire tech en 2032.',
      stat: 22.47,
      statLabel: 'Mercado 2032',
      prefix: '$',
      suffix: 'B',
    },
  ];

  const trustBadges = [
    { label: 'Normativa DGAC' },
    { label: 'DAN 151' },
    { label: 'DAN 91' },
    { label: 'Dronivo 🇩🇪' },
  ];

  return (
    <section className="py-24 md:py-32 bg-slate-950 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, rgb(248 250 252) 1px, transparent 0)',
          backgroundSize: '48px 48px',
        }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">Por Qué Ahora</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-16 text-balance"
          >
            La ventana de oportunidad{' '}
            <span className="text-forest-400">está abierta</span>
          </motion.h2>

          {/* Three Pillars Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {pillars.map((pillar, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: 0.1 * index }}
              >
                <Card hover className="h-full text-center">
                  {/* Icon */}
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary-500/10 border-2 border-primary-500/30 flex items-center justify-center">
                    <pillar.icon className="w-8 h-8 text-primary-500" />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold mb-3 text-primary-400">
                    {pillar.title}
                  </h3>

                  {/* Stat */}
                  <div className="mb-4">
                    {typeof pillar.stat === 'number' && pillar.stat > 100 ? (
                      <Counter
                        end={pillar.stat}
                        label=""
                        prefix={pillar.prefix}
                        suffix={pillar.suffix}
                        format={false}
                      />
                    ) : (
                      <div className="text-4xl font-mono font-bold text-accent-500">
                        {pillar.prefix}{pillar.stat}{pillar.suffix}
                      </div>
                    )}
                    <div className="text-sm text-slate-400 mt-1">
                      {pillar.statLabel}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-slate-300 leading-relaxed">
                    {pillar.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Quote */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="max-w-4xl mx-auto mb-12"
          >
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 md:p-8">
              <p className="text-lg md:text-xl text-slate-200 italic mb-3 leading-relaxed text-center">
                "Los drones ofrecen despliegue rápido, penetran el humo con cámaras térmicas para revelar focos ocultos, y optimizan la asignación de recursos durante emergencias."
              </p>
              <p className="text-sm text-slate-400 font-medium text-center">
                — Unmanned Systems Technology, 2024
              </p>
            </div>
          </motion.div>

          {/* Trust Badges */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <div className="flex flex-wrap items-center justify-center gap-4">
              {trustBadges.map((badge, index) => (
                <div
                  key={index}
                  className="px-6 py-3 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 font-medium text-sm hover:border-primary-500/50 transition-colors"
                >
                  {badge.label}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyNow;
