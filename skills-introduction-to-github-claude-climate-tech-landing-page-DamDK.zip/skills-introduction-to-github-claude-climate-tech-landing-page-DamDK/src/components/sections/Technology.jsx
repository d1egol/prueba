import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import Card from '../ui/Card';

const Technology = () => {
  const techCards = [
    {
      title: 'Drones de Vigilancia',
      image: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?w=800&q=80',
      specs: [
        'Cámaras térmicas HD',
        'Vuelo autónomo',
        'Operación 24/7',
        '10+ km de cobertura',
      ],
    },
    {
      title: 'Inteligencia Artificial',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
      specs: [
        'Detección en segundos',
        'Análisis predictivo',
        '98% precisión',
        'Aprendizaje continuo',
      ],
    },
    {
      title: 'Centro de Control',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
      specs: [
        'Dashboard tiempo real',
        'Integración CONAF',
        'Alertas multicanal',
        'Reportería automática',
      ],
    },
    {
      title: 'Respuesta con Drones',
      image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=800&q=80',
      specs: [
        'Carga de retardante',
        'Espuma biodegradable',
        'Despliegue < 5 min',
        'Coordinación terrestre',
      ],
    },
  ];

  return (
    <section id="tecnologia" className="py-24 md:py-32 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary-500/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">Tecnología</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-8 text-balance"
          >
            Componentes de{' '}
            <span className="bg-gradient-to-r from-primary-400 to-accent-400 bg-clip-text text-transparent">
              clase mundial
            </span>
          </motion.h2>

          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/30 text-primary-400">
              <span className="text-xl">🇩🇪</span>
              <span className="text-sm font-medium">Socio tecnológico: Dronivo (Alemania)</span>
            </div>
          </motion.div>

          {/* Tech Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {techCards.map((card, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: 0.1 * index }}
              >
                <Card hover className="overflow-hidden p-0 h-full">
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={card.image}
                      alt={card.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-2xl font-bold mb-4 text-primary-400">
                      {card.title}
                    </h3>

                    {/* Specs List */}
                    <ul className="space-y-3">
                      {card.specs.map((spec, specIndex) => (
                        <li key={specIndex} className="flex items-start gap-3">
                          <Check className="w-5 h-5 text-forest-500 flex-shrink-0 mt-0.5" />
                          <span className="text-slate-300">{spec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Note */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-center"
          >
            <p className="text-slate-400 text-sm italic">
              La configuración exacta se define según cada proyecto
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Technology;
