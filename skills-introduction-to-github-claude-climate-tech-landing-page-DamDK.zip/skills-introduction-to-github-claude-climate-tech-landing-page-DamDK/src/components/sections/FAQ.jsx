import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ArrowRight } from 'lucide-react';
import Button from '../ui/Button';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: '¿Cuánto cuesta un proyecto?',
      answer: 'Cada proyecto es único. Depende de la cobertura, terreno y nivel de integración necesarios. En la reunión inicial podemos darte un rango estimado basado en tus requerimientos específicos. Los proyectos típicamente van desde $200K a $1M+ USD, incluyendo hardware, software, instalación y servicio mensual.',
    },
    {
      question: '¿Cumplen con la regulación DGAC?',
      answer: 'Sí. Diseñamos cada proyecto para cumplir con DAN 151 (operación de drones) y DAN 91 (operaciones comerciales). Incluimos todo el proceso de permisos y certificaciones como parte del servicio. Nuestro equipo está familiarizado con los requisitos regulatorios chilenos.',
    },
    {
      question: '¿Tienen proyectos funcionando en Chile?',
      answer: 'Estamos en fase de validación con pilotos iniciales. Nuestro socio tecnológico Dronivo tiene casos de éxito documentados en Europa con tecnología similar que adaptamos al contexto y regulación chilena. Esto nos permite ofrecer tecnología probada con personalización local.',
    },
    {
      question: '¿Se integra con sistemas existentes de CONAF?',
      answer: 'Sí. Parte del diseño a medida incluye la integración con los sistemas y protocolos que ya utilizas. Podemos conectarnos con sistemas de alerta de CONAF, SENAPRED y otros sistemas de gestión de emergencias. La interoperabilidad es una prioridad en cada proyecto.',
    },
    {
      question: '¿Cuánto tiempo toma implementar?',
      answer: 'Desde la firma del contrato hasta operación completa: típicamente 2-4 meses. Esto incluye diseño final, adquisición de permisos, instalación de hardware, configuración de software, entrenamiento del equipo y pruebas en campo. El tiempo exacto depende de la complejidad y los permisos regulatorios necesarios.',
    },
  ];

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const scrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="faq" className="py-24 md:py-32 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent-500/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">Preguntas Frecuentes</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-16 text-balance"
          >
            Lo que probablemente{' '}
            <span className="text-primary-400">te estás preguntando</span>
          </motion.h2>

          {/* FAQ Accordion */}
          <div className="space-y-4 mb-12">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: 0.05 * index }}
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className={`w-full text-left bg-slate-800/50 backdrop-blur-sm border rounded-2xl p-6 transition-all duration-300 ${
                    openIndex === index
                      ? 'border-primary-500 bg-slate-800/70'
                      : 'border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="text-lg md:text-xl font-semibold text-slate-100">
                      {faq.question}
                    </h3>
                    <motion.div
                      animate={{ rotate: openIndex === index ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                      className="flex-shrink-0"
                    >
                      <ChevronDown
                        className={`w-6 h-6 ${
                          openIndex === index ? 'text-primary-400' : 'text-slate-400'
                        }`}
                      />
                    </motion.div>
                  </div>

                  <AnimatePresence>
                    {openIndex === index && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <p className="text-slate-300 leading-relaxed mt-4 pt-4 border-t border-slate-700">
                          {faq.answer}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </button>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center"
          >
            <p className="text-slate-300 mb-6">
              ¿Tienes otra pregunta?
            </p>
            <Button
              variant="secondary"
              size="lg"
              onClick={scrollToContact}
              icon={<ArrowRight size={20} />}
            >
              Conversemos
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
