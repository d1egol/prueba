import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, FileText, Rocket, Target, Calendar } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const HowItWorks = () => {
  const steps = [
    {
      number: '01',
      icon: MessageCircle,
      title: 'CONVERSAMOS',
      description: 'Entendemos tu operación, terreno y desafíos específicos',
      timeline: '1-2 semanas',
    },
    {
      number: '02',
      icon: FileText,
      title: 'DISEÑAMOS',
      description: 'Creamos una propuesta técnica y financiera a medida',
      timeline: '2-4 semanas',
    },
    {
      number: '03',
      icon: Rocket,
      title: 'IMPLEMENTAMOS',
      description: 'Instalamos, configuramos y operamos el sistema contigo',
      timeline: '4-12 semanas',
    },
  ];

  const scrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="proceso" className="py-24 md:py-32 bg-slate-950 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(to right, rgb(248 250 252) 1px, transparent 1px), linear-gradient(to bottom, rgb(248 250 252) 1px, transparent 1px)',
          backgroundSize: '64px 64px',
        }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-center mb-6"
          >
            <span className="section-label">Cómo Trabajamos</span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-16 text-balance"
          >
            Un proceso consultivo,{' '}
            <span className="text-primary-400">no una venta de producto</span>
          </motion.h2>

          {/* Timeline */}
          <div className="relative mb-16">
            {/* Horizontal Line - Hidden on mobile */}
            <div className="hidden md:block absolute top-20 left-0 right-0 h-1 bg-gradient-to-r from-primary-500 via-accent-500 to-forest-500 opacity-20" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="relative"
                >
                  {/* Step Number */}
                  <div className="text-6xl font-bold text-slate-700 mb-4 text-center md:text-left">
                    {step.number}
                  </div>

                  <Card hover className="text-center md:text-left relative z-10">
                    {/* Icon */}
                    <div className="w-16 h-16 mx-auto md:mx-0 mb-4 rounded-full bg-primary-500 flex items-center justify-center">
                      <step.icon className="w-8 h-8 text-white" />
                    </div>

                    {/* Title */}
                    <h3 className="text-2xl font-bold mb-3 text-primary-400">
                      {step.title}
                    </h3>

                    {/* Description */}
                    <p className="text-slate-300 mb-4 leading-relaxed">
                      {step.description}
                    </p>

                    {/* Timeline */}
                    <div className="inline-block px-3 py-1 rounded-full bg-slate-700/50 text-sm text-slate-400">
                      {step.timeline}
                    </div>
                  </Card>

                  {/* Vertical Connector on Mobile */}
                  {index < steps.length - 1 && (
                    <div className="md:hidden h-8 w-1 bg-gradient-to-b from-primary-500 to-accent-500 opacity-20 mx-auto" />
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Exclusivity Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="max-w-2xl mx-auto mb-12"
          >
            <div className="bg-forest-500/10 border border-forest-500/30 rounded-2xl p-6 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Target className="w-6 h-6 text-forest-500" />
                <h4 className="text-xl font-bold text-forest-400">
                  Plazas Limitadas
                </h4>
              </div>
              <p className="text-slate-300 text-lg">
                Aceptamos máximo <span className="font-bold text-forest-400">3 proyectos piloto</span> durante 2026
              </p>
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-center"
          >
            <Button
              variant="primary"
              size="lg"
              onClick={scrollToContact}
              icon={<Calendar size={20} />}
            >
              Iniciar Conversación
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
