import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { Mail, MapPin, CheckCircle2, AlertCircle, Send } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';

const Contact = () => {
  const [formState, setFormState] = useState('idle'); // idle | submitting | success | error

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  const onSubmit = async (data) => {
    setFormState('submitting');

    // Simulación de envío (en producción, aquí iría la llamada a la API)
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Simulación de éxito
    console.log('Form data:', data);
    setFormState('success');

    // Reset después de 5 segundos
    setTimeout(() => {
      reset();
      setFormState('idle');
    }, 5000);
  };

  const organizationTypes = [
    'Empresa forestal',
    'Gobierno / CONAF',
    'Municipalidad',
    'Agroindustria',
    'Inversionista',
    'Otro',
  ];

  return (
    <section
      id="contacto"
      className="py-24 md:py-32 bg-gradient-to-b from-slate-950 via-accent-950/20 to-slate-950 relative overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-accent-500/10 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-center mb-6 text-balance"
          >
            ¿Listo para proteger{' '}
            <span className="bg-gradient-to-r from-forest-400 to-primary-400 bg-clip-text text-transparent">
              lo que importa?
            </span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-slate-300 text-center mb-16"
          >
            Agenda una reunión estratégica. Sin compromiso.
          </motion.p>

          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card>
                {formState === 'success' ? (
                  // Success State
                  <div className="text-center py-8">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                    >
                      <CheckCircle2 className="w-16 h-16 text-forest-500 mx-auto mb-4" />
                    </motion.div>
                    <h3 className="text-2xl font-bold text-forest-400 mb-2">
                      ¡Mensaje enviado!
                    </h3>
                    <p className="text-slate-300">
                      Gracias por tu interés. Nos pondremos en contacto en máximo 48 horas.
                    </p>
                  </div>
                ) : (
                  // Form
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    {/* Nombre */}
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">
                        Nombre *
                      </label>
                      <input
                        id="name"
                        type="text"
                        {...register('name', { required: 'El nombre es requerido' })}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="Tu nombre completo"
                        disabled={formState === 'submitting'}
                      />
                      {errors.name && (
                        <p className="mt-1 text-sm text-alert-400 flex items-center gap-1">
                          <AlertCircle size={14} />
                          {errors.name.message}
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                        Email corporativo *
                      </label>
                      <input
                        id="email"
                        type="email"
                        {...register('email', {
                          required: 'El email es requerido',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'Email inválido',
                          },
                        })}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="tu@empresa.com"
                        disabled={formState === 'submitting'}
                      />
                      {errors.email && (
                        <p className="mt-1 text-sm text-alert-400 flex items-center gap-1">
                          <AlertCircle size={14} />
                          {errors.email.message}
                        </p>
                      )}
                    </div>

                    {/* Organización */}
                    <div>
                      <label htmlFor="organization" className="block text-sm font-medium text-slate-300 mb-2">
                        Organización *
                      </label>
                      <input
                        id="organization"
                        type="text"
                        {...register('organization', { required: 'La organización es requerida' })}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="Nombre de tu empresa o institución"
                        disabled={formState === 'submitting'}
                      />
                      {errors.organization && (
                        <p className="mt-1 text-sm text-alert-400 flex items-center gap-1">
                          <AlertCircle size={14} />
                          {errors.organization.message}
                        </p>
                      )}
                    </div>

                    {/* Tipo de organización */}
                    <div>
                      <label htmlFor="orgType" className="block text-sm font-medium text-slate-300 mb-2">
                        Tipo de organización *
                      </label>
                      <select
                        id="orgType"
                        {...register('orgType', { required: 'Selecciona un tipo' })}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        disabled={formState === 'submitting'}
                      >
                        <option value="">Seleccionar...</option>
                        {organizationTypes.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                      {errors.orgType && (
                        <p className="mt-1 text-sm text-alert-400 flex items-center gap-1">
                          <AlertCircle size={14} />
                          {errors.orgType.message}
                        </p>
                      )}
                    </div>

                    {/* Mensaje */}
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">
                        Mensaje (opcional)
                      </label>
                      <textarea
                        id="message"
                        {...register('message')}
                        rows={4}
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
                        placeholder="Cuéntanos brevemente sobre tu desafío..."
                        disabled={formState === 'submitting'}
                      />
                    </div>

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      variant="primary"
                      size="lg"
                      fullWidth
                      disabled={formState === 'submitting'}
                      icon={<Send size={20} />}
                    >
                      {formState === 'submitting' ? 'Enviando...' : 'Enviar Mensaje'}
                    </Button>

                    <p className="text-sm text-slate-400 text-center">
                      Responderemos en máximo 48 horas
                    </p>
                  </form>
                )}
              </Card>
            </motion.div>

            {/* Information */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col justify-center space-y-8"
            >
              {/* Contact Info */}
              <div className="space-y-6">
                <h3 className="text-2xl font-bold mb-4">También puedes escribirnos:</h3>

                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-primary-400 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-slate-300 font-medium">Email</p>
                    <a
                      href="mailto:contacto@firewatch.cl"
                      className="text-primary-400 hover:text-primary-300 transition-colors"
                    >
                      contacto@firewatch.cl
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-primary-400 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-slate-300 font-medium">Ubicación</p>
                    <p className="text-slate-400">San Antonio, Chile</p>
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-slate-700" />

              {/* Quote */}
              <div className="bg-slate-900/50 border border-slate-700 rounded-2xl p-6">
                <p className="text-lg text-slate-200 italic mb-3 leading-relaxed">
                  "Cada proyecto comienza con una conversación. Cuéntanos tu desafío."
                </p>
                <p className="text-sm text-slate-400 font-medium">
                  — Diego, Fundador
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
